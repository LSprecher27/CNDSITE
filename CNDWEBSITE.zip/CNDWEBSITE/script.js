// Add the filename here whenever you drop a new image in the folder
const products = ['BT-01'];

const grid = document.getElementById('product-grid');

products.forEach(id => {
    const item = document.createElement('div');
    item.className = 'product-item';
    
    item.innerHTML = `
        <img src="products/${id}.jpg" alt="${id}">
        <div class="product-id">${id}</div>
    `;
    
    grid.appendChild(item);
});